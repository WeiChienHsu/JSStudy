sheetjs.github.io
=================

Source for the website <http://oss.sheetjs.com>

Stress tests are available at <http://oss.sheetjs.com/stress.html>

[![Build Status](https://saucelabs.com/browser-matrix/sheetjs.svg)](https://saucelabs.com/u/sheetjs)

[![Build Status](https://travis-ci.org/SheetJS/SheetJS.github.io.svg?branch=master)](https://travis-ci.org/SheetJS/SheetJS.github.io)

[![ghit.me](https://ghit.me/badge.svg?repo=sheetjs/js-xlsx)](https://ghit.me/repo/sheetjs/js-xlsx)

[![Analytics](https://ga-beacon.appspot.com/UA-36810333-1/SheetJS/SheetJS.github.io?pixel)](https://github.com/SheetJS/SheetJS.github.io)

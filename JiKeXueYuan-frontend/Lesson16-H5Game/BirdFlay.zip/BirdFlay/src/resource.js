/**
 * Created by xiangsongtao on 15/11/4.
 */
var res = {
    bird_img : "res/bird.png",
    continue_img : "res/continue.png",
    scene_img : "res/scene.jpg",
    start_img : "res/start.png"
};

var g_resource = [];
for (var i in res){
    g_resource.push(res[i]);
}

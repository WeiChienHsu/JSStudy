# full-stack-tinyurl
This is a service to convert longurl into shorturl.Use MEAN stack and redis, ngix.

#### Run mutiple backend servers</br>
If you want to try run local, download it and go to the folder.</br>
in command line, type:  docker-compose --build up.</br>
This will start 3 backend server and ngix do load balance.</br>

#### Run single server
cd app</br>
node server.js</br>
(If you have nodemon installed global)</br>
nodemon server.js</br>


contact info: zhangwei112030@gmail.com



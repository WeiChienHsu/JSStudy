require "test_helper"

class Plate::MapTest < Minitest::Test
  def test_that_it_has_a_version_number
    refute_nil ::Plate::Map::VERSION
  end

  def test_it_does_something_useful
    assert false
  end
end

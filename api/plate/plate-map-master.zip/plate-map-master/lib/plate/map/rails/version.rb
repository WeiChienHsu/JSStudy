module Plate
  module Map
    module Rails
      VERSION = "0.1.0"
    end
  end
end

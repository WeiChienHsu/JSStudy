module Plate
  module Map
    module Rails
      class Engine < ::Rails::Engine
      end
    end
  end
end
require 'plate/map/rails/engine'
require 'plate/map/rails/version'
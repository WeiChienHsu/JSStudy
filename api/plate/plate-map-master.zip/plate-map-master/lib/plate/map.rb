require "plate/map/rails/version"

